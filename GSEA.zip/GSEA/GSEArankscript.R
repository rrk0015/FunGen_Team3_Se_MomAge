####  Preparing DGE result for Functional Enrichment Analysis ###
# Functional Genomics BIOL: 6850
# This file uses the dds object produced by the DGEseq2, and the statistical results file that was written.

############ Preparing Data for GSEA and Cytoscape.  #############

### Merge 'gene names' with DGE results by Gene Model (gene_id)

## Import Annotation file with results from Blast to databases

Anno <- read.csv("DP.csv")
summary(Anno)
dim(Anno)
head(Anno)
## Import the DGE results files make sure the gene model name is 'gene_id' to match annotation file
DGEresults0 <- read.csv("limma-voom_Dose0.csv", stringsAsFactors = FALSE)
summary(DGEresults0)
dim(DGEresults0)

DGEresults102 <- read.csv("limma-voom_Dose102.csv", stringsAsFactors = FALSE)
summary(DGEresults102)
dim(DGEresults102)


DGEresults408 <- read.csv("limma-voom_Dose408.csv", stringsAsFactors = FALSE)
summary(DGEresults408)
dim(DGEresults408)
## Merge anno with DGE results. Merging by gene_id (the first column). 
# The all.y=FALSE will result in only the rows that are in common between the two files
DGE_Anno_0 <- merge(Anno,DGEresults0,by="gene_id",all.y = FALSE)
dim(DGE_Anno_0)
head(DGE_Anno_0)
write.csv(as.data.frame(DGE_Anno_0), file="LV0GeneName.csv", row.names=FALSE)

DGE_Anno_102 <- merge(Anno,DGEresults102,by="gene_id",all.y = FALSE)
dim(DGE_Anno_102)
head(DGE_Anno_102)
write.csv(as.data.frame(DGE_Anno_102), file="LV102GeneName.csv", row.names=FALSE)

DGE_Anno_408 <- merge(Anno,DGEresults408,by="gene_id",all.y = FALSE)
dim(DGE_Anno_408)
head(DGE_Anno_408)
write.csv(as.data.frame(DGE_Anno_408), file="LV408GeneName.csv", row.names=FALSE)



############################# Make ranked lists for GSEA ####################
## Here we are calculating a rank for each gene, and adding that column
## The rank is based on the log2fold change (how up or down regulated they are) and the pvalue (significance) 
DGE_Anno_0 <-  within(DGE_Anno_0, rank <- sign(logFC) * -log10(adj.P.Val))
head(DGE_Anno_0)

DGE_Anno_102 <-  within(DGE_Anno_102, rank <- sign(logFC) * -log10(adj.P.Val))
head(DGE_Anno_102)

DGE_Anno_408 <-  within(DGE_Anno_408, rank <- sign(logFC) * -log10(adj.P.Val))
head(DGE_Anno_408)

#subset the results so only Gene Name and rank
DGE_rank0 = subset(DGE_Anno_0, select = c(gene_id,rank) )
head(DGE_rank0)

DGE_rank102 = subset(DGE_Anno_102, select = c(gene_id,rank) )
head(DGE_rank102)

DGE_rank408 = subset(DGE_Anno_408, select = c(gene_id,rank) )
head(DGE_rank408)

#subset the results so only rows with a Name and rank
DGE_rank0_withName <- na.omit(DGE_rank0)
dim(DGE_rank0_withName)

DGE_rank102_withName <- na.omit(DGE_rank102)
dim(DGE_rank102_withName)

DGE_rank408_withName <- na.omit(DGE_rank408)
dim(DGE_rank408_withName)


## for use in GSEA preranked analysis, the file must be tab delimitied and end in .rnk
write.table(DGE_rank0_withName, file="LV0.rnk", sep = "\t", row.names=FALSE)

write.table(DGE_rank102_withName, file="LV102.rnk", sep = "\t", row.names=FALSE)

write.table(DGE_rank408_withName, file="LV408.rnk", sep = "\t", row.names=FALSE)  
