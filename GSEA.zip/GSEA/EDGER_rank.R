
## Import Annotation file with results from Blast to databases
Anno <- read.csv("DP.csv", stringsAsFactors = FALSE, na.strings=c(""))
head(Anno)

## Import the DGE results file make sure the gene model name is 'gene_id' to match annotation file
EDGER <- read.csv("EdgeR.csv", stringsAsFactors = FALSE)
head(EDGER)
dim(EDGER)

EDGER$gene_id <- gsub("gene-","",as.character(EDGER$gene_id))

## Merge anno with DGE results. Merging by gene_id (the first column). 
# The all.y=FALSE will result in only the rows that are in common between the two files
EDGER_Anno <- merge(Anno,EDGER,by="gene_id",all.y = FALSE)
dim(EDGER_Anno)
summary(EDGER_Anno)
head(EDGER_Anno)

write.csv(as.data.frame(EDGER_Anno), file="EDGER_results_GeneName.csv", row.names=FALSE) 

############################# Make ranked list for GSEA ####################
## Here we are calculating a rank for each gene, and adding that column
## The rank is based on the log2fold change (how up or down regulated they are) and the pvalue (significance) 
EDGER_AnnoRank <-  within(EDGER_Anno, rank <- sign(logFC) * -log10(PValue))
EDGER_AnnoRank 

#subset the results so only Gene Name and rank
EDGRrank = subset(EDGER_AnnoRank, select = c(gene_id,rank) )
EDGRrank

#subset the results so only rows with a Name and rank
DGErank_withName <- na.omit(EDGRrank)
DGErank_withName
dim(DGErank_withName)

#write.csv(as.data.frame(DGErank_withName), file="DGErankName.csv", row.names=FALSE) 
## for use in GSEA preranked analysis, the file must be tab delimitied and end in .rnk
write.table(DGErank_withName, file="EDGER_Y_Low_vs_High.rnk", sep = "\t", row.names=FALSE)  
